# RH Management — Static Site
Deploy-ready, single-file static website using Tailwind CDN.

## Quick Deploy (Vercel — Drag & Drop)
1) Go to https://vercel.com/new (login).
2) Click **Import** → **Other** → drag-and-drop the folder in this ZIP.
3) Project settings: Framework = **Other**, Root Directory = `/`.
4) Deploy. You’ll get a preview URL like `https://rhmanagement.vercel.app`.
5) To connect your domain:
   - Settings → **Domains** → add `rhmanagement.com`
   - Follow Vercel’s DNS instructions at your domain registrar (A/AAAA or CNAME).

## Quick Deploy (Netlify — Drop)
1) Go to https://app.netlify.com/drop
2) Drag `index.html` in — done.
3) To use your domain: Site settings → Domain management → Add domain `rhmanagement.com` and follow DNS steps.

## Email Button
The contact button opens the default mail client to `contact@rhmanagement.com`. Change it after you set up email.

## Edit Content
- Open `index.html`, search sections: Hero, Services, Selected Work, About, Contact.
- Replace placeholder case studies and texts with real data.
