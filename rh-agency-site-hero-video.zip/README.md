
# RH Agency — Hero Video + Rotating Greeting

Ganti file berikut agar persis kebutuhanmu:
- `assets/video/hero.mp4`  ← taruh video kamu di sini (MP4 H.264, 8–15s, muted, <12MB).
- `assets/img/hero-poster.svg` ← poster/fallback (boleh ganti JPG/WEBP).
- Ubah daftar sapaan di `assets/js/main.js` (array `greets`).
- Edit teks judul/CTA di `index.html` bagian `.hero-content`.

**Tips video:**
- 1920×1080 (atau 1280×720 hemat), loop mulus, tanpa audio (muted).
- iOS/Android autoplay butuh `muted` + `playsinline`.
- Koneksi lambat → video otomatis tidak autoplay (lihat main.js).

Upload semua isi folder ke hosting (mis. `public_html/`). 
