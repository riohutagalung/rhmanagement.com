
// Mobile nav
const toggle = document.querySelector('.nav-toggle');
const menu = document.getElementById('menu');
if (toggle && menu){
  toggle.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}

// Rotating greeting
const greets = [
  "Selamat datang",
  "Welcome",
  "欢迎光临",
  "ようこそ",
  "환영합니다",
  "Bienvenido",
  "مرحبا"
];
const greetEl = document.getElementById('greet');
let i = 0;
function rotateGreet(){
  if(!greetEl) return;
  greetEl.classList.add('fade-out');
  setTimeout(() => {
    i = (i + 1) % greets.length;
    greetEl.textContent = greets[i];
    greetEl.classList.remove('fade-out');
  }, 350);
}
setInterval(rotateGreet, 2400);

// Fallback: pause video on very slow connections
const video = document.getElementById('heroVideo');
if (video){
  // If Data Saver or low power mode might be on
  if (navigator.connection && (navigator.connection.saveData || (navigator.connection.effectiveType||'').includes('2g'))){
    video.removeAttribute('autoplay');
    video.pause();
  }
}
